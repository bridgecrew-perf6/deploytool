package define

type StatusType int

const (
	SaveData = "SaveData"
	GetData  = "GetData"
)

type CommonData struct {
	BusinessId string `json:"business_id"` //业务相关ID
}

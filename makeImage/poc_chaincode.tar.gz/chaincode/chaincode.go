package main

import (
	"fmt"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
	"github.com/peersafe/fabric_poc/chaincode/define"
	"github.com/peersafe/fabric_poc/chaincode/handler"
	"github.com/peersafe/fabric_poc/chaincode/utils"
)

type handlerFunc func(stub shim.ChaincodeStubInterface, args []string) ([]byte, error)

var funcHandler = map[string]handlerFunc{
	define.SaveData: handler.SaveData,
	define.GetData:  handler.GetData,
}

type Chaincode struct {
}

func (t *Chaincode) Init(stub shim.ChaincodeStubInterface) peer.Response {
	utils.Logger.Debug("Init Chaincode...")
	return shim.Success([]byte("SUCCESS"))
}

func (t *Chaincode) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	function, args := stub.GetFunctionAndParameters()
	utils.Logger.Debugf("Invoke function=%v,args=%v\n", function, args)

	if len(args) < 1 || len(args[0]) == 0 {
		err := fmt.Sprintf("the invoke args length < 1 or arg[0] is empty")
		utils.Logger.Error(err)
		return shim.Error(err)
	}

	currentFunc, ok := funcHandler[function]
	if !ok {
		err := fmt.Sprintf("the function name not exist")
		utils.Logger.Error(err)
		return shim.Error(err)
	}

	payload, err := currentFunc(stub, args)
	if err != nil {
		utils.Logger.Error(err)
		return shim.Error(err.Error())
	}
	return shim.Success(payload)
}

func main() {
	err := shim.Start(new(Chaincode))
	if err != nil {
		utils.Logger.Errorf("Error starting chaincode: %s", err)
	}
}

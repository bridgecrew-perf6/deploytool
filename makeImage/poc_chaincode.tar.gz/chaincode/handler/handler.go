package handler

import (
	"github.com/hyperledger/fabric/core/chaincode/shim"

	"encoding/json"
	"github.com/peersafe/fabric_poc/chaincode/define"
	"github.com/peersafe/fabric_poc/chaincode/utils"
)

func SaveData(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	if err := stub.PutState(stub.GetTxID(), []byte(args[0])); err != nil {
		return utils.ResponseFailed("save data txid failed err: %v", err)
	}

	var data define.CommonData
	_ = json.Unmarshal([]byte(args[0]), &data)
	if data.BusinessId != "" {
		if err := stub.PutState("BusinessId_"+data.BusinessId, []byte(stub.GetTxID())); err != nil {
			return utils.ResponseFailed("save data businessId failed err: %v", err)
		}
	}
	return nil, nil
}

func GetData(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	utils.Logger.Debugf("data query by id: %s\n", args[0])
	res, err := stub.GetState("BusinessId_" + args[0])
	if err != nil {
		return utils.ResponseFailed("data query failed to GetState Business err: %v", err)
	}
	if res == nil {
		return stub.GetState(args[0])
	} else {
		return stub.GetState(string(res))
	}
}

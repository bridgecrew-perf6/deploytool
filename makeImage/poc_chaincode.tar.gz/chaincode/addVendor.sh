#!/usr/bin/env bash
govendor add github.com/peersafe/fabric_poc/chaincode/define github.com/peersafe/fabric_poc/chaincode/handler github.com/peersafe/fabric_poc/chaincode/utils
package utils

import (
	"encoding/json"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/pkg/errors"
)

var Logger = shim.NewLogger("chaincode")

func ResponseFailed(format string, a ...interface{}) ([]byte, error) {
	err := errors.Errorf(format, a...)
	Logger.Error("Response failed: ", err.Error())
	return nil, err
}

func PutData(stub shim.ChaincodeStubInterface, data interface{}, putKey string) error {

	putData, err := json.Marshal(data)
	if err != nil {
		return err
	}

	if err := stub.PutState(putKey, putData); err != nil {
		return err
	}

	return nil

}

package main

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-chaincode-go/shim"
	pb "github.com/hyperledger/fabric-protos-go/peer"
)

type MsgData struct {
	MsgSn string `json:"msgSn"` //业务编号
}

type ResponseMsg struct {
	ErrCode int    `json:"errcode"` //错误ID
	ErrMsg  string `json:"errmsg"`  //错误消息
	Data    string `json:"data"`    //正文
	TxId    string `json:"txid"`    //交易id
}

const ERR_CODE_DATA_NOT_FOUND = 100
const ERR_CODE = 999
const SUCCESS_CODE = 0

// CommonCC Chaincode implementation
type CommonCC struct {
}

func (t *CommonCC) Init(stub shim.ChaincodeStubInterface) pb.Response {
	fmt.Println("CommonCC init")
	return shim.Success(nil)
}

func (t *CommonCC) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	function, args := stub.GetFunctionAndParameters()
	fmt.Printf("Invoke function=%v,args=%v\n", function, args)
	if len(args) < 1 || len(args[0]) == 0 {
		err := fmt.Sprintf("the invoke args length < 1 or arg[0] is empty")
		return shim.Error(err)
	}
	if function == "saveData" {
		return t.saveData(stub, args)
	} else if function == "getDataByMsgSn" {
		return t.getDataByMsgSn(stub, args)
	}
	return shim.Error("Invalid invoke function name.")
}

//saveData
func (t *CommonCC) saveData(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var msgData MsgData
	if err := json.Unmarshal([]byte(args[0]), &msgData); err != nil {
		return shim.Error(fmt.Sprintf("saveData unmarshal err:%s", err.Error()))
	}
	err := stub.PutState("txId_"+msgData.MsgSn, []byte(stub.GetTxID()))
	if err != nil {
		return shim.Error(fmt.Sprintf("saveData pustate txid err:%s", err.Error()))
	}
	err = stub.PutState(msgData.MsgSn, []byte(args[0]))
	if err != nil {
		return shim.Error(fmt.Sprintf("saveData pustate data err:%s", err.Error()))
	}
	return shim.Success(nil)
}

//getDataByMsgSn
func (t *CommonCC) getDataByMsgSn(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	var responseMsg ResponseMsg
	responseMsg.ErrCode = ERR_CODE
	responseMsg.ErrMsg = ""
	msgSn := args[0]
	txId, err := stub.GetState("txId_" + msgSn)
	if err != nil {
		responseMsg.ErrMsg = "txId:" + err.Error()
		responseMsg.ErrCode = ERR_CODE_DATA_NOT_FOUND
		responseMsgByte, _ := json.Marshal(responseMsg)
		return shim.Success(responseMsgByte)
	}
	msgDataBytes, err := stub.GetState(msgSn)
	if err != nil {
		responseMsg.ErrMsg = "msgSn:" + err.Error()
		responseMsg.ErrCode = ERR_CODE_DATA_NOT_FOUND
		responseMsgByte, _ := json.Marshal(responseMsg)
		return shim.Success(responseMsgByte)
	}
	if msgDataBytes == nil {
		responseMsg.ErrMsg = "msgSn: [" + msgSn + "] not found"
		responseMsg.ErrCode = ERR_CODE_DATA_NOT_FOUND
		responseMsgByte, _ := json.Marshal(responseMsg)
		return shim.Success(responseMsgByte)
	}

	responseMsg.ErrCode = SUCCESS_CODE
	responseMsg.Data = string(msgDataBytes)
	responseMsg.TxId = string(txId)
	responseMsgByte, _ := json.Marshal(responseMsg)
	return shim.Success(responseMsgByte)
}

func main() {
	err := shim.Start(new(CommonCC))
	if err != nil {
		fmt.Printf("Error starting CommonCC chaincode: %s", err)
	}
}
